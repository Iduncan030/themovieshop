
export const ACCESS = import.meta.env.VITE_ACCESS;
export const API_KEY = import.meta.env.VITE_API_KEY;

export const BASE_URL = "https://api.themoviedb.org/3";
export const BASE_IMG = "https://image.tmdb.org/t/p";