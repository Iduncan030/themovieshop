import styles from "./TrendingAll.module.scss";

function TrendingAll({ children }) {
    return <div className={styles.trendingAll}>{children}</div>;
}

export default TrendingAll;
